EXTREME CAR RACING — OFFLINE ANDROID PROJECT

Yeh Android Studio ka source project hai, APK nahi.

ZAROORI: Game ko offline chalane ke liye official Three.js r128 ki browser file three.min.js is folder mein rakhein:
app/src/main/assets/game/three.min.js

HTML ko local file load karne ke liye badal diya gaya hai. Is environment mein Three.js library download nahi ho saki, isliye woh ZIP mein shamil nahi hai. Jab tak yeh file add nahi hoti, 3D game start nahi hoga.

Build karne ke liye Android Studio mein folder kholen, file add karein, Gradle sync karein, phir Build > Build APK(s) chunen. APK ko airplane mode mein test karke hi share karein.

Is ZIP mein APK shamil nahi hai.