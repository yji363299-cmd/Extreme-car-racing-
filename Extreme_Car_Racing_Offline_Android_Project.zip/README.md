# Extreme Car Racing — Offline Android project

This is an Android Studio WebView wrapper for the existing 3D HTML game.

## Important status
- This ZIP is Android project source, NOT an APK.
- The game HTML is bundled locally.
- To make the game fully offline, add the official Three.js r128 browser build as:
  `app/src/main/assets/game/three.min.js`
- The original game depended on Three.js from a CDN. The HTML now points to the local file.
- The Three.js library could not be downloaded in this environment, so it is deliberately not included. Until it is added, the 3D game will not launch.

## Build
1. Open this folder in Android Studio.
2. Add `three.min.js` at the path above.
3. Let Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Test airplane mode before sharing the APK.

No internet permission is declared in the Android manifest. Build-time Gradle dependency downloads still require internet.
